﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vjezba3C
{
    class Uplatnica
    {
        private string platIme;
        private string platAdr;
        private string primIme;
        private string primAdr;
        private bool hitno;
        private string valuta;
        private string iznos;
        private string model;
        private string pozivPlat;
        private string pozivPrim;
        private string sifra;
        private string opis;
        private string iban;
        private DateTime datum;

        public static Uplatnica AddUpl(string platIme, string platAdr, string primIme, string primAdr, bool hitno, string valuta, string iznos, string model, string pozivPlat, string pozivPrim, string sifra, string opis, string iban, DateTime datum)
        {
            Uplatnica nova = new Uplatnica();
            nova.platIme = platIme;
            nova.platAdr = platAdr;
            nova.primIme = primIme;
            nova.primAdr = primAdr;
            nova.hitno = hitno;
            nova.valuta = valuta;
            nova.iznos = iznos;
            nova.model = model;
            nova.pozivPlat = pozivPlat;
            nova.pozivPrim = pozivPrim;
            nova.sifra = sifra;
            nova.opis = opis;
            nova.iban = iban;
            nova.datum = datum;
            return nova;
        }
        public string getImePrim()
        {
            return this.primIme;
        }
        public string getImePlat()
        {
            return this.platIme;
        }
        public string getAdrPrim()
        {
            return this.primAdr;
        }
        public string getAdrPlat()
        {
            return this.platAdr;
        }
        public bool getHitno()
        {
            return this.hitno;
        }
        public string getValuta()
        {
            return this.valuta;
        }
        public string getIznos()
        {
            return this.iznos;
        }
        public string getModel()
        {
            return this.model;
        }
        public string getPozivPlat()
        {
            return this.pozivPlat;
        }
        public string getPozivPrim()
        {
            return this.pozivPrim;
        }
        public string getSifra()
        {
            return this.sifra;
        }
        public string getOpis()
        {
            return this.opis;
        }
        public string getIban()
        {
            return this.iban;
        }
        public DateTime getDatum()
        {
            return this.datum;
        }

    }
}
